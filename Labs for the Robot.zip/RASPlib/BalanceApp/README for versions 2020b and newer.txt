This balance code and app are designed to be used for 2020b and newer
Please contact me: joshua.hurst.rpi@gmail.com if you would like this adopted for a previous version.