

void BMP280_Init(void);
void BMP280_Read(float* pfData);
