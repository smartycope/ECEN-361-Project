 #ifdef __cplusplus
extern "C" {
#endif

void int2bytes(unsigned char* pfData, int int_in);

#ifdef __cplusplus
}
#endif


