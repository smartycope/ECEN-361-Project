
void QMC5883_Init(void);
void QMC5883_Read(float* pfData);
