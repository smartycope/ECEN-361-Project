
void HCSR04Sonar_Init(int trigger_pin, int echo_pin, int Sonar);
int HCSR04Sonar_Read(int Sonar);

