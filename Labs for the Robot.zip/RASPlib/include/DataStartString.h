#include "rtwtypes.h"

#ifdef __cplusplus
extern "C" {
#endif
   
void Send_Data_Start_String();

#ifdef __cplusplus
}
#endif

