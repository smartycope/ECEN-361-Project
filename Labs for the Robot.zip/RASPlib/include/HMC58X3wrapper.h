

void HMC58X3_Init(void);
void HMC58X3_Read(float* pfData);

