
void BMI160Gyro_Init(void);
void BMI160Gyro_Read(int* pfData);

